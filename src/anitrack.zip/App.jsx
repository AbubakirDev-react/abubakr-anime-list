import { useState } from 'react';
import {Routes,Route} from 'react-router-dom';
import HeroPage from './pages/HeroPage'; 
import HomePage from './pages/HomePage';
import Navbar from './components/Navbar';
import LoginPage from './pages/auth/LoginPage';
import RegisterPage from './pages/auth/RegisterPage';
import AuthProvider, { useAuth } from './context/AuthContext';

function App() {
  const {loggedIn}=useAuth();

  return (
    <AuthProvider>
    <div>
      <Navbar/>
      <Routes>
        <Route path='/' element={<HomePage />} />
        <Route path='/login' element={<LoginPage />}/>
        <Route path='/register' element={<RegisterPage /> } />
      </Routes>
    </div>
    </AuthProvider>
  )
}

export default App
